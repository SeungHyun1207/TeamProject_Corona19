
public class Reservelist extends Person { // �����ڸ���Ʈ

	/*
	 * ArrayList<String> reserveName = new ArrayList<String>(); //�̸�����Ʈ
	 * ArrayList<String> gender = new ArrayList<String>(); // ��������Ʈ
	 * ArrayList<Integer> phoneNum = new ArrayList<Integer>(); //��ȭ��ȣ����Ʈ
	 * ArrayList<Integer> age = new ArrayList<Integer>(); // ���̸���Ʈ
	 */

	private String name; // ������ �̸�
	private String gender; // ����
	private String phoneNum; // ��ȭ��ȣ
	private int age; // ����
	private String dayNum; // ���೯¥
	private String seattype; // �ڸ�Ÿ��

	public Reservelist(String name, String gender, String phoneNum, int age, String dayNum, String seattype) { // ������
		super();
		this.name = name;
		this.gender = gender;
		this.phoneNum = phoneNum;
		this.age = age;
		this.dayNum = dayNum;
		this.seattype = seattype;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDayNum() {
		return dayNum;
	}

	public void setDayNum(String dayNum) {
		this.dayNum = dayNum;
	}

	public String getSeattype() {
		return seattype;
	}

	public void setSeattype(String seattype) {
		this.seattype = seattype;
	}
}
